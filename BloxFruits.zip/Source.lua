local Message=Instance.new("Message",workspace);Message.Text="Script return date: January 9th\ndiscord.gg/7aR7kNVt4g";game:GetService("Debris"):AddItem(Message, 10)
