return {
  ["Bright Yellow"] = {
    EtcItems = {
      { Name = "Yellow Star Berry", Amount = 1 }
    }
  },
  ["Yellow Sunshine"] = {
    EtcItems = {
      { Name = "Yellow Star Berry", Amount = 1 },
      { Name = "White Cloud Berry", Amount = 1 }
    }
  },
  ["Snow White"] = {
    EtcItems = {
      { Name = "White Cloud Berry", Amount = 10 }
    }
  },
  ["Orange Soda"] = {
    EtcItems = {
      { Name = "Orange Berry", Amount = 1 }
    }
  },
  ["Fiery Rose"] = {
    EtcItems = {
      { Name = "Pink Pig Berry", Amount = 2 },
      { Name = "Red Cherry Berry", Amount = 2 }
    }
  },
  Dragon = {
    EtcItems = {
      { Name = "Red Cherry Berry", Amount = 6 },
      { Name = "Pink Pig Berry", Amount = 8 },
      { Name = "Orange Berry", Amount = 3 }
    }
  },
  ["Green Lizard"] = {
    EtcItems = {
      { Name = "Green Toad Berry", Amount = 1 },
      { Name = "White Cloud Berry", Amount = 1 }
    }
  },
  ["Plump Purple"] = {
    EtcItems = {
      { Name = "Purple Jelly Berry", Amount = 3 }
    }
  },
  ["Winter Sky"] = {
    EtcItems = {
      { Name = "Pink Pig Berry", Amount = 15 }
    }
  },
  ["Pure Red"] = {
    EtcItems = {
      { Name = "Red Cherry Berry", Amount = 15 }
    }
  }
}
