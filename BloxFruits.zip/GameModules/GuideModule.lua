return { Data = { LastClosestNPC = "" } }
